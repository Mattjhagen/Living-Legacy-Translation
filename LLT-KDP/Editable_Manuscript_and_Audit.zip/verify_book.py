import json,pathlib,re,subprocess,concurrent.futures,xml.etree.ElementTree as ET,hashlib,collections
from pypdf import PdfReader,PdfWriter
ROOT=pathlib.Path(__file__).resolve().parent.parent;W=ROOT/'work';P=W/'interiors';S=W/'editable-source'
POP='/Users/matt/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/poppler/bin/pdftotext'
QA=W/'qa';QA.mkdir(exist_ok=True)
manifest=json.loads((W/'volume-manifest.json').read_text());scripture=[json.loads(l) for l in (S/'scripture.jsonl').read_text().splitlines()];notes=[json.loads(l) for l in (S/'print-notes.jsonl').read_text().splitlines()]
def compact(s):return re.sub(r'\s+','',s)
def verify(m):
 path=P/m['file'];reader=PdfReader(path);writer=PdfWriter();fonts=[]
 for page in reader.pages:
  fs=page['/Resources']['/Font'];embedded=[obj for obj in fs.values() if obj.get_object().get('/FontDescriptor')]
  if embedded:
   for key,obj in list(fs.items()):
    fo=obj.get_object()
    if fo.get('/Subtype')=='/Type1' and not fo.get('/FontDescriptor'):fs[key]=embedded[0]
  writer.add_page(page)
 writer._info=None;tmp=path.with_suffix('.verified.pdf')
 with tmp.open('wb') as f:writer.write(f)
 tmp.replace(path);reader=PdfReader(path)
 subprocess.run([POP,'-bbox-layout',str(path),str(QA/(path.stem+'.html'))],check=True,capture_output=True)
 tree=ET.parse(QA/(path.stem+'.html'));root=tree.getroot();ns={'x':'http://www.w3.org/1999/xhtml'};pages=root.findall('.//x:page',ns)
 words=[el for page in pages for el in page.findall('.//x:word',ns)];text=''.join(el.text or '' for el in words if float(el.attrib['yMin'])>=40 and float(el.attrib['yMax'])<=677);ct=compact(text)
 relevant=[];pos=0
 for d in scripture:
  key=f"{d['book']} {d['chapter']}"
  if key not in m['chapter_pages']:continue
  relevant.append(d)
  for v in d['verses']:
   needle=compact(v['text']);found=ct.find(needle,pos)
   if found<0:raise AssertionError(f"Scripture text missing: {key}:{v['number']}")
   pos=found+len(needle)
 note_missing=[];count=0
 for d in relevant:
  dn=[n for n in notes if n['book_slug']==d['book_slug'] and n['chapter']==d['chapter']]
  for n in dn:
   count+=1
   if compact(n['text']) not in ct:note_missing.append(n['id'])
 assert not note_missing,(path.name,note_missing)
 out=[]
 for pageno,page in enumerate(pages,1):
  assert float(page.attrib['width'])==504 and float(page.attrib['height'])==720
  for el in page.findall('.//x:word',ns):
   a=el.attrib
   if float(a['xMin'])<44 or float(a['xMax'])>460 or float(a['yMin'])<18 or float(a['yMax'])>697:out.append({'page':pageno,'word':el.text,'bounds':a})
 assert not out,(path.name,out[:4])
 names={}
 for page in reader.pages:
  assert list(page.mediabox)==[0,0,504,720];assert not page.get('/Annots');assert not reader.is_encrypted
  for obj in page['/Resources']['/Font'].values():
   fo=obj.get_object();desc=fo.get('/FontDescriptor');assert desc and any(k in desc.get_object() for k in ['/FontFile','/FontFile2','/FontFile3']),fo
   names[str(fo['/BaseFont'])]=True
 assert not reader.outline
 assert len(pages)==m['pages']
 return {'file':path.name,'pages':len(pages),'verses_verified':sum(len(d['verses']) for d in relevant),'notes_verified':count,'fonts':list(names),'out_of_bounds_words':len(out),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 results=list(pool.map(verify,manifest))
archive=P/'Archived_Insights_Reference_Register.pdf'
archive_result=verify({'file':archive.name,'pages':len(PdfReader(archive).pages),'chapter_pages':{}})
archive_text=compact(''.join(el.text or '' for el in ET.parse(QA/(archive.stem+'.html')).getroot().findall('.//{http://www.w3.org/1999/xhtml}word') if float(el.attrib['yMin'])>=40 and float(el.attrib['yMax'])<=677))
qrows=[json.loads(l) for l in (S/'quarantined-notes.jsonl').read_text().splitlines()]
assert all(compact(t) in archive_text for t in {q['record']['note'] for q in qrows})
groups=collections.defaultdict(list)
names={b['slug']:b['name'] for b in json.loads((S/'repository-evidence/json/books_index.json').read_text())['books']}
for q in qrows:
 n=q['record'];slug=pathlib.Path(q['source']).stem;groups[(slug,n['chapter'],q['template_id'],n['kind'],n.get('asOf',''),n['attribution'])].append(n['verse'])
def ranges(values):
 values=sorted(set(values));out=[];start=last=values[0]
 for v in values[1:]:
  if v==last+1:last=v
  else:out.append(str(start) if start==last else f'{start}-{last}');start=last=v
 out.append(str(start) if start==last else f'{start}-{last}');return ', '.join(out)
for (slug,ch,tid,kind,date,attr),vs in groups.items():
 line=f'{names[slug]} {ch}:{ranges(vs)} | {tid} | {kind} | {attr}'+(f' | as of {date}' if date else '')
 assert compact(line) in archive_text,line
archive_result['reference_groups_verified']=len(groups)
archive_result['archived_records_in_source']=len(qrows);archive_result['archived_templates_verified']=len({q['record']['note'] for q in qrows});results.append(archive_result)
(W/'verification.json').write_text(json.dumps(results,indent=2));(S/'verification.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
