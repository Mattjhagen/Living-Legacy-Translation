import json, pathlib, re, collections, hashlib, csv, zipfile, html, shutil, math, copy
from html.parser import HTMLParser
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak, NextPageTemplate, Flowable
from reportlab.pdfgen.canvas import Canvas
from pypdf import PdfReader, PdfWriter

ROOT=pathlib.Path(__file__).resolve().parent.parent
R=ROOT/'work/repository'; O=ROOT/'outputs'; W=ROOT/'work'; S=W/'editable-source'; P=W/'interiors'
for d in [S,P,O]:d.mkdir(parents=True,exist_ok=True)
BOOKS=json.loads((R/'json/books_index.json').read_text())['books']
SHA='e74570b23c94800202042424a76af5bec848db01'
FONT=pathlib.Path('/Users/matt/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/LibreOfficeDev.app/Contents/Resources/fonts/truetype')
for name,file in [('Body','LiberationSerif-Regular.ttf'),('Bold','LiberationSerif-Bold.ttf'),('Italic','LiberationSerif-Italic.ttf')]:pdfmetrics.registerFont(TTFont(name,str(FONT/file)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Italic',boldItalic='Bold')
WIDTH,HEIGHT=504,720; INNER,OUTER=63,45; BOTTOM,TOP=47,47; FW=396; FH=626
styles={
 'body':ParagraphStyle('body',fontName='Body',fontSize=10.5,leading=13.5,spaceAfter=2,allowWidows=0,allowOrphans=0),
 'note':ParagraphStyle('note',fontName='Body',fontSize=10.5,leading=13.5,spaceAfter=5,allowWidows=0,allowOrphans=0),
 'h1':ParagraphStyle('h1',fontName='Bold',fontSize=23,leading=27,spaceBefore=16,spaceAfter=14,keepWithNext=True),
 'h2':ParagraphStyle('h2',fontName='Bold',fontSize=16,leading=20,spaceBefore=15,spaceAfter=10,keepWithNext=True),
 'h3':ParagraphStyle('h3',fontName='Bold',fontSize=11,leading=14,spaceBefore=12,spaceAfter=7,keepWithNext=True),
 'small':ParagraphStyle('small',fontName='Body',fontSize=9,leading=12,spaceAfter=7),
 'title':ParagraphStyle('title',fontName='Body',fontSize=30,leading=35,spaceAfter=20),
}
def esc(s):return html.escape(str(s)).replace('\n','<br/>')
def para(s,style='body',raw=False):return Paragraph(s if raw else esc(s),styles[style])
def norm(s):return ' '.join(s.split())
chapters=[]; audit={'commit':SHA,'date':'2026-11-05','coverage_gaps':[],'coverage_overlaps':[],'invalid_note_refs':[],'schema_issues':[],'empty_footnotes':0,'llt_web_differences':0,'books':[]}
ledger=[]; unique_notes=[]; note_keys={}; note_reftext={}; chapter_index={}
for b in BOOKS:
 slug=b['slug']; paths=sorted((R/'json/llt'/slug).glob('*.json'),key=lambda p:int(p.stem))
 for p in paths:
  d=json.loads(p.read_text()); d['notes']=[];d['source']=str(p.relative_to(R));chapters.append(d);chapter_index[(slug,d['chapter'])]=d
  w=json.loads((R/'json/web'/slug/p.name).read_text())
  audit['llt_web_differences']+=d['verses']!=w['verses']
  assert len(d['verses'])==d['verse_count']
  assert [v['number'] for v in d['verses']]==list(range(1,len(d['verses'])+1))
 audit['books'].append({'book':b['name'],'chapters':len(paths),'verses':sum(len(chapter_index[(slug,int(p.stem))]['verses']) for p in paths)})

def add_note(slug,n,source,index,layer):
 ch=n.get('chapter');v=n.get('verse');end=n.get('verseEnd',n.get('verse_end',v));text=n.get('note',n.get('content',''))
 if layer=='chapter':ch=index[0];index=index[1]
 if not text.strip():audit['empty_footnotes']+=1;ledger.append({'source':source,'index':index,'layer':layer,'printed_id':None,'record':n});return
 key=(slug,ch,v,end,text)
 if layer=='chapter' and (slug,ch,v,text) in note_reftext:
  nn=note_reftext[(slug,ch,v,text)]
  nn['sources'].append({'path':source,'index':index,'layer':layer})
  ledger.append({'source':source,'index':index,'layer':layer,'printed_id':nn['id'],'record':n});return
 if key not in note_keys:
  ident=f'N{len(unique_notes)+1:05d}'
  nn={'id':ident,'book_slug':slug,'chapter':ch,'verse':v,'end':end,'text':text,'kind':n.get('kind',n.get('know',n.get('key','unclassified'))),'attribution':n.get('attribution',n.get('author','Unspecified')),'asOf':n.get('asOf'),'sources':[]}
  note_keys[key]=nn;note_reftext[(slug,ch,v,text)]=nn;unique_notes.append(nn)
  if (slug,ch) not in chapter_index:audit['invalid_note_refs'].append({'source':source,'index':index,'record':n})
  else:
   chapter_index[(slug,ch)]['notes'].append(nn)
   if v is not None and (v<1 or end>len(chapter_index[(slug,ch)]['verses'])):audit['invalid_note_refs'].append({'source':source,'index':index,'record':n})
 nn=note_keys[key];nn['sources'].append({'path':source,'index':index,'layer':layer})
 ledger.append({'source':source,'index':index,'layer':layer,'printed_id':nn['id'],'record':n})

slugset={b['slug'] for b in BOOKS}
activepaths=sorted((R/'data/insights').glob('*.json'))
for p in activepaths:
 if p.name.startswith('_'):continue
 slug=p.stem if p.stem in slugset else re.sub(r'-\d+$','',p.stem)
 for i,n in enumerate(json.loads(p.read_text())):
  if any(k not in n for k in ['verse','kind','attribution']) or 'verse_end' in n:
   audit['schema_issues'].append({'source':str(p.relative_to(R)),'index':i,'keys':list(n)})
  add_note(slug,n,str(p.relative_to(R)),i,'active')
for d in chapters:
 for i,n in enumerate(d['footnotes']):add_note(d['book_slug'],n,d['source'],(d['chapter'],i),'chapter')

for d in chapters:
 d['notes'].sort(key=lambda n:(n['verse'] if n['verse'] is not None else 0,n['id']))
 cov=collections.Counter(v for n in d['notes'] if n['verse'] is not None for v in range(n['verse'],n['end']+1))
 for v in d['verses']:
  k=v['number'];ref=f"{d['book']} {d['chapter']}:{k}"
  if not cov[k]:audit['coverage_gaps'].append(ref)
  if cov[k]>1:audit['coverage_overlaps'].append({'ref':ref,'notes':cov[k]})

# Independent publisher edition comparison. Preserve repository wording, report differences.
z=zipfile.ZipFile(W/'official-web.zip')
codes='GEN EXO LEV NUM DEU JOS JDG RUT 1SA 2SA 1KI 2KI 1CH 2CH EZR NEH EST JOB PSA PRO ECC SNG ISA JER LAM EZK DAN HOS JOL AMO OBA JON MIC NAM HAB ZEP HAG ZEC MAL MAT MRK LUK JHN ACT ROM 1CO 2CO GAL EPH PHP COL 1TH 2TH 1TI 2TI TIT PHM HEB JAS 1PE 2PE 1JN 2JN 3JN JUD REV'.split()
class OfficialParser(HTMLParser):
 def __init__(self):super().__init__();self.main=False;self.current=None;self.skip=0;self.marker=False;self.verses=collections.defaultdict(str)
 def handle_starttag(self,t,a):
  a=dict(a)
  if t=='div' and a.get('class')=='main':self.main=True
  if not self.main:return
  if self.skip:self.skip+=1;return
  if a.get('class') in ['notemark','tnav','footnote','copyright'] or a.get('class','').startswith('s') and t=='div':self.skip=1;return
  if t=='span' and a.get('class')=='verse':self.current=int(a['id'][1:]);self.marker=True
 def handle_endtag(self,t):
  if self.skip:self.skip-=1;return
  if t=='span' and self.marker:self.marker=False
  if self.current is not None:self.verses[self.current]+=' '
 def handle_data(self,s):
  if self.main and self.current is not None and not self.skip and not self.marker:self.verses[self.current]+=s

comparison=[];refdiff=[]
for b,code in zip(BOOKS,codes):
 for d in [c for c in chapters if c['book_slug']==b['slug']]:
  ch=d['chapter'];filename=('PS201.htm' if code=='PSA' and ch==151 else f'{code}{ch:03d}.htm' if code=='PSA' else f'{code}{ch:02d}.htm')
  if filename not in z.namelist():refdiff.append({'book':b['name'],'chapter':ch,'error':'publisher file not found','file':filename});continue
  p=OfficialParser();p.feed(z.read(filename).decode('utf-8-sig'));official=p.verses
  for v in d['verses']:
   ov=norm(official.get(v['number'],''));text=norm(v['text'])
   if text!=ov:comparison.append({'ref':f"{d['book']} {ch}:{v['number']}",'repository':text,'publisher_current':ov,'publisher_file':filename})
  expected={v['number'] for v in d['verses']}
  if expected!=set(official):refdiff.append({'book':b['name'],'chapter':ch,'repository_verses':len(expected),'publisher_verses':len(official),'missing':sorted(set(official)-expected),'extra':sorted(expected-set(official))})
audit['publisher_comparison']={'differing_verse_texts':len(comparison),'reference_differences':refdiff,'zip_sha256':hashlib.sha256((W/'official-web.zip').read_bytes()).hexdigest(),'source':'https://ebible.org/Scriptures/eng-web_html.zip'}

def label(n):
 v='chapter' if n['verse'] is None else str(n['verse'])+(f"-{n['end']}" if n['end']!=n['verse'] else '')
 return f"{n['chapter']}:{v} | {n['kind']} | {n['attribution']}"+(f" | as of {n['asOf']}" if n.get('asOf') else '')
def chapter_flow(d,bookstart=False):
 out=[]
 if bookstart:out.append(para(d['book'],'h1'))
 out.append(para(f"{d['book']} {d['chapter']}",'h2'))
 if d['book_slug']=='psalms' and d['chapter']==151:out.append(para('Psalm 151 is retained as an additional psalm from the repository. Its canonical status differs among traditions.','small'))
 for v in d['verses']:out.append(para(f"<b>{v['number']}</b>  {esc(v['text'])}",raw=True))
 if d['notes']:
  out.append(para('Heirloom Insights','h3'))
  for n in d['notes']:out.append(para(f"<b>{esc(label(n))}</b><br/>{esc(n['text'])}",'note',True))
 return out

# Calculate volume breaks at chapter boundaries from actual paragraph heights.
groups=[];group=[];used=0;previous=None
for d in chapters:
 flow=chapter_flow(d,previous!=d['book_slug']);height=sum(f.wrap(FW,FH)[1]+f.getSpaceBefore()+f.getSpaceAfter() for f in flow)
 if group and used+height>FH*590:groups.append(group);group=[];used=0;previous=None;height+=45
 group.append(d);used+=height*1.025;previous=d['book_slug']
if group:groups.append(group)

page_records=[]
class LoggedParagraph(Paragraph):pass
class BookDoc(BaseDocTemplate):
 def __init__(self,path,volume):
  super().__init__(str(path),pagesize=(WIDTH,HEIGHT),leftMargin=INNER,rightMargin=OUTER,topMargin=TOP,bottomMargin=BOTTOM,pageCompression=1)
  self.volume=volume;self.book='';self.chapter='';self.bounds=[];self.locators={}
  self.addPageTemplates([PageTemplate(id='odd',frames=[Frame(INNER,BOTTOM,FW,FH,leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=self.page,autoNextPageTemplate='even'),PageTemplate(id='even',frames=[Frame(OUTER,BOTTOM,FW,FH,leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=self.page,autoNextPageTemplate='odd')])
 def page(self,c,doc):
  c.saveState();c.setFillColorRGB(0,0,0);c.setFont('Body',8.5)
  if doc.page>2:
   c.drawString(INNER if doc.page%2 else OUTER,HEIGHT-30,f'The Rooted Translation  |  Volume {self.volume}')
   c.drawRightString(WIDTH-(OUTER if doc.page%2 else INNER),HEIGHT-30,'Scripture and Heirloom Insights')
  c.drawCentredString(WIDTH/2,29,str(doc.page));c.restoreState()
 def afterFlowable(self,f):
  if isinstance(f,Paragraph):
   text=f.getPlainText()
   if f.style.name=='h2':self.chapter=text;self.locators[text]=self.page
   y=self.frame._y;self.bounds.append({'page':self.page,'y_bottom':round(y,2),'height':f.height,'style':f.style.name})

def clean_pdf(path):
 reader=PdfReader(path);writer=PdfWriter();writer.append_pages_from_reader(reader);writer.add_metadata({})
 if '/Info' in writer._root_object:del writer._root_object['/Info']
 writer._info=None
 tmp=path.with_suffix('.clean.pdf')
 with tmp.open('wb') as f:writer.write(f)
 tmp.replace(path)

license_text=(R/'LICENSE').read_text()
manifest=[]
for i,group in enumerate(groups,1):
 first,last=group[0],group[-1];span=f"{first['book']} {first['chapter']} to {last['book']} {last['chapter']}"
 filename=f'Rooted_Translation_Volume_{i:02d}.pdf';path=P/filename
 story=[Spacer(1,85),para('The Rooted<br/>Translation','title',True),para('Scripture with Heirloom Insights','h2'),para(f'Volume {i} of {len(groups)}','h2'),para(span),Spacer(1,22),para('Living Legacy Translation source edition','small'),PageBreak()]
 story += [para('About this edition','h2'),para('Scripture is reproduced from the Living Legacy Translation repository. The repository scripture is identical to its stored World English Bible data. This edition does not claim a new translation from the biblical languages.','small'),para('The notes are AI-generated devotional reflections, textual observations, and dated echoes. First-person memories in these notes are a literary voice, not verified human testimony. Notes are distinct from Scripture and do not carry its authority.','small'),para('All nonempty active notes are retained. Exact duplicate notes at the same reference and range print once; source records and attribution details are retained in the companion archive. Alternative notes and overlapping ranges remain separate. Notes follow each chapter and identify their verse or range.','small'),para('The underlying World English Bible translation is public domain. Its name is a trademark used here to identify the source, not to certify this transcription as an unchanged official edition. https://worldenglish.bible/','small'),para(f'Source revision {SHA}.','small'),para('Repository license notice','h3'),para(license_text,'small'),PageBreak()]
 story.append(para('Contents','h1'))
 # Page numbers added after the first layout, same number and size of lines.
 toc=[]
 for bslug,ds in __import__('itertools').groupby(group,key=lambda d:d['book_slug']):
  ds=list(ds);entry=f"{ds[0]['book']}  |  Chapters {ds[0]['chapter']}-{ds[-1]['chapter']}";toc.append((len(story),entry,f"{ds[0]['book']} {ds[0]['chapter']}"));story.append(para(entry,'small'))
 story.append(PageBreak());prev=None
 md=[f'# The Rooted Translation\n\n## Volume {i} of {len(groups)}\n\n{span}\n']
 for d in group:
  story+=chapter_flow(d,prev!=d['book_slug']);prev=d['book_slug']
  md.append(f"\n## {d['book']} {d['chapter']}\n")
  for v in d['verses']:md.append(f"**{v['number']}** {v['text']}\n")
  md.append('\n### Heirloom Insights\n')
  for n in d['notes']:md.append(f"**{label(n)} [{n['id']}]**\n\n{n['text']}\n")
 doc=BookDoc(path,i);doc.build(copy.deepcopy(story))
 for index,entry,key in toc:story[index]=para(f'{entry}  . . .  {doc.locators[key]}','small')
 doc=BookDoc(path,i);doc.build(story[:]);clean_pdf(path)
 count=len(PdfReader(path).pages);assert 24<=count<=828,(filename,count)
 (S/f'Volume_{i:02d}.md').write_text('\n'.join(md))
 manifest.append({'volume':i,'file':filename,'span':span,'pages':count,'chapters':len(group),'verses':sum(len(d['verses']) for d in group),'notes':sum(len(d['notes']) for d in group),'chapter_pages':doc.locators})
 page_records.append({'file':filename,'bounds':doc.bounds})
 print(filename,count,span,flush=True)

# Full archive of quarantined records; compact print appendix preserves all assignments.
qrows=[];templates={};qmap=collections.defaultdict(list)
for p in sorted((R/'data/insights-quarantine').glob('*.json')):
 if p.name.startswith('_'):continue
 for index,n in enumerate(json.loads(p.read_text())):
  key=n['note'];tid=templates.setdefault(key,f'Q{len(templates)+1}')
  qrows.append({'source':str(p.relative_to(R)),'index':index,'template_id':tid,'record':n})
  qmap[(p.stem,n['chapter'],tid,n['kind'],n.get('asOf',''),n['attribution'])].append(n['verse'])
def ranges(values):
 out=[];values=sorted(set(values));start=last=values[0]
 for v in values[1:]:
  if v==last+1:last=v
  else:out.append(str(start) if start==last else f'{start}-{last}');start=last=v
 out.append(str(start) if start==last else f'{start}-{last}');return ', '.join(out)
qstory=[para('Archived Insights','h1'),para('Quarantined source records','h2'),para('These records were placed in insights-quarantine in the source repository. They are preserved for completeness and are not part of the active commentary. The three repeated texts are printed once below. The reference register assigns every archived record to its exact text, kind, attribution, and date. Original individual JSON records are in the editable source archive.'),]
for text,tid in templates.items():qstory +=[para(tid,'h3'),para(text)]
qstory +=[PageBreak(),para('Reference register','h1')]
names={b['slug']:b['name'] for b in BOOKS}
for (slug,ch,tid,kind,date,attr),vs in sorted(qmap.items(),key=lambda x:(next(b['order'] for b in BOOKS if b['slug']==x[0][0]),x[0][1],x[0][2])):
 qstory.append(para(f"{names[slug]} {ch}:{ranges(vs)} | {tid} | {kind} | {attr}"+(f' | as of {date}' if date else ''),'small'))
qpath=P/'Archived_Insights_Reference_Register.pdf';qd=BookDoc(qpath,'Archive');qd.build(qstory);clean_pdf(qpath)

# Data, provenance, reproducibility and editable manuscript.
for name,rows in [('source-note-ledger.jsonl',ledger),('quarantined-notes.jsonl',qrows),('print-notes.jsonl',unique_notes)]:
 with (S/name).open('w') as f:
  for row in rows:f.write(json.dumps(row,ensure_ascii=False)+'\n')
with (S/'scripture.jsonl').open('w') as f:
 for d in chapters:f.write(json.dumps({k:v for k,v in d.items() if k not in ['notes','footnotes']},ensure_ascii=False)+'\n')
with (S/'publisher-text-differences.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=['ref','repository','publisher_current','publisher_file']);writer.writeheader();writer.writerows(comparison)
audit.update({'books_count':len(BOOKS),'chapters':len(chapters),'verses':sum(len(d['verses']) for d in chapters),'scripture_words':sum(len(v['text'].split()) for d in chapters for v in d['verses']),'active_source_records':sum(1 for l in ledger if l['layer']=='active'),'unique_print_notes':len(unique_notes),'print_note_words':sum(len(n['text'].split()) for n in unique_notes),'chapter_footnote_records':sum(len(d['footnotes']) for d in chapters),'quarantined_records':len(qrows),'quarantined_unique_texts':len(templates),'volume_count':len(groups),'total_interior_pages':sum(m['pages'] for m in manifest),'archived_register_pages':len(PdfReader(qpath).pages)})
(S/'audit-data.json').write_text(json.dumps(audit,indent=2));(S/'volume-manifest.json').write_text(json.dumps(manifest,indent=2));(W/'layout-bounds.json').write_text(json.dumps(page_records));(W/'audit-data.json').write_text(json.dumps(audit,indent=2));(W/'volume-manifest.json').write_text(json.dumps(manifest,indent=2))
for path in ['LICENSE','README.md','AGENTS.md','json/books_index.json','data/insights/_progress.json','data/insights-quarantine/_progress.json']:
 dst=S/'repository-evidence'/path;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/path,dst)
with zipfile.ZipFile(S/'repository-text-snapshot.zip','w',zipfile.ZIP_DEFLATED) as zz:
 for folder in ['json','markdown','data/insights','data/insights-quarantine','scripts','bible']:
  for p in (R/folder).rglob('*'):
   if p.is_file():zz.write(p,str(p.relative_to(R)))
shutil.copy2(__file__,S/'build_book.py')
print(json.dumps({k:v for k,v in audit.items() if k not in ['books','coverage_overlaps','schema_issues','publisher_comparison']},indent=2),flush=True)
