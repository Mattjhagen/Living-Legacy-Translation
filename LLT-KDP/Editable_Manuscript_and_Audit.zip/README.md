# The Rooted Translation print manuscript

This is an eight-volume editorial proof preserving the complete repository Scripture and active notes, with a separate archived-notes register. Read Publication_Audit.md before commercial use. Nothing has been published.

Edit Volume_01.md through Volume_08.md for the manuscript text. Scripture and note source records are in JSONL files. source-note-ledger.jsonl maps every original active/chapter record, including empty placeholders and duplicate copies, to its printed note ID. print-notes.jsonl holds the consolidated notes. quarantined-notes.jsonl retains every archived record. repository-text-snapshot.zip preserves the full relevant repository files at e74570b23c94800202042424a76af5bec848db01.

Use chapter-page-index.csv to locate a chapter in the PDFs. Page numbering restarts in each volume. Notes follow each chapter. Referenced verse ranges and original attribution are retained; missing categories are marked unclassified. Markdown emphasis markers in source note text are preserved as literal source characters in this proof.

Claims were screened across the corpus; individual scholarly verification is incomplete. reviewed-claims.csv records specific reviewed findings and proposed changes; claims-review-queue.csv is an unverified triage queue. Do not apply the proposed corrections blindly.

The PDFs use paperback black ink/white paper, 7 × 10 inch trim, no bleed. They are not specified for hardcover. Covers and final publication metadata remain to be prepared after editorial and rights decisions.

To reconstruct the original build workspace, place build_book.py in work/, extract repository-text-snapshot.zip into work/repository/, and supply the publisher archive at work/official-web.zip. The script uses Python 3.12 with reportlab and pypdf and local Liberation Serif font files; configure FONT and ROOT for your environment. verify_book.py requires bundled Poppler pdftotext. These scripts record the production procedure; the editable manuscript is the Markdown/JSONL, not a Word file.
